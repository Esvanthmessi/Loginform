<html>
<body>
<h1>welcome</h1>
<table>
<tr>
<th>s.no</th>
<th>FirstName</th>
<th>Lastname</th>
<th>Father</th>
<th>phone</th>
<th>Password</th>
</tr>

<?php
										require 'config.php';
										$query2 = "SELECT * FROM info";
										$query_run2 = mysqli_query($db, $query2);

										if(mysqli_num_rows($query_run2) > 0)
										{
											$sn=1;
											foreach($query_run2 as $student2)
											{
                                    ?>

                                            <tr>
                                                <td><?php echo $sn++;?></td>
												 <td><?= $student2['fname'] ?></td> 
												 <td><?= $student2['lname'] ?></td>
												  <td><?= $student2['father'] ?></td>
												  <td><?= $student2['phone'] ?></td>
												  <td><?= $student2['pass'] ?></td>

                                                
										
										</td>
                                                
                                            </tr>

                                     <?php
											}
												$sn=$sn+1;
                            }
                            ?>
							
</table>
</body>
</html>